#include "SalesAnalysis_Persist.h"
#include "../Service/Sale.h"
#include "stdio.h"

int Sale_Perst_SelByTicket(int ticket_id,sale_t *sale){//以ID获取销售记录

    int found = 0;
    sale_node_t *temp;
    FILE *fp;

    fp=fopen("Sale.bat","rb");
    if(fp==NULL){
        printf("fopen failed!");
        return found;
    }

    while(!feof(fp)){
        if(fread(temp,sizeof(sale_node_t),1,fp)){
            if(ticket_id==temp->data.id){
                sale=&(temp->data);
                found=1;
            }
        }
    }
    fclose(fp);
    return found;
}