#ifndef SALESANALYSIS_PERSIST_H
#define SALESANALYSIS_PERSIST_H

#include "../Service/Sale.h"

int Sale_Perst_SelByTicket(int ticket_id,sale_t *sale);

#endif