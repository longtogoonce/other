#ifndef MAIN_MENU_H_
#define MAIN_MENU_H_

//ϵͳ���˵� 
void Main_Menu(void);

#endif /* MAIN_MENU_H_ */
