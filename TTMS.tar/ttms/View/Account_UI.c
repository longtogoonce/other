
#include "../View/Account_UI.h"
#include <stdio.h>
#include <string.h>
#include "../Common/list.h"
#include "../Service/Account.h"
#include <termios.h>
#include <unistd.h>
#include <assert.h>
#include "MaiAccount_UI.h"

static const int Account_PAGE_SIZE = 5;
const int len1 = 20;

account_t gl_CurUser;

void print(unsigned char decrypt[])
{
	for (int i = 0; i < 16; i++)
	{
		printf("%02x", decrypt[i]);
	}
}
int getch()
{
	int c = 0;
	struct termios org_opts, new_opts;
	int res = 0;

	res = tcgetattr(STDIN_FILENO, &org_opts);
	assert(res == 0);

	memcpy(&new_opts, &org_opts, sizeof(new_opts));
	new_opts.c_lflag &= ~(ICANON | ECHO | ECHOE | ECHOK | ECHONL | ICRNL);
	tcsetattr(STDIN_FILENO, TCSANOW, &new_opts);
	c = getchar();

	res = tcsetattr(STDIN_FILENO, TCSANOW, &org_opts);
	assert(res == 0);
	return c;
}

//系统登录
int SysLogin()
{
	system("clear");
    printf("\n\t\t=========================================================================================================");
    printf("\n\t\t*********************************Welcome To TTMS********************************************************");
    printf("\n\t\t========================================================================================================");
	printf("\n\t\t																									 "    );
	printf("\n\t\t																									 "    );
	printf("\n\t\t																									 "    );
	printf("\n\t\t																									 "    );
	printf("\n\t\t																									 "    );
	printf("\n\t\tPress Enter to start logging:																		 "    );
 	printf("\n\t\t=======================================================================================================\n");
	while(getchar()!='\n');																						
	
	Account_Srv_InitSys();
	int x = 2;
	while (x > 0)
	{
		char usrName[35], pwd[35];
		printf("\n\t\tplease input you name :");
		setbuf(stdin, NULL);

		gets(usrName);

		printf("\t\tplease input you password :");
		setbuf(stdin, NULL);

		for (int i = 0; i < len1; i++)
		{
			pwd[i] = getch();
			if (pwd[i] == '\n')
			{
				pwd[i] = '\0';
				break;
			}
			if ((int)pwd[i] == 127)
			{
				printf("\b \b");
				i = i - 2;
			}
			else
			{
				printf("*");
			}
			if (i < 0)
				pwd[0] = '\0';
		}

		if (Account_Srv_Verify(usrName, pwd))
		{
			printf("\n\t\tWelcome distinguished users,please input [Enter]!\n");
			while(getchar()!='\n');
			return 1;
		}
		else
		{
			printf("\t\tlogin in error");
			printf("\n\t\tYou have %d login opportunities", x);
			x--;
		}
	}
	printf("%d\n",x);
	if(x==0){
		char cho;
		printf("\n\t\tWhether to retrieve the Password\n [Y]es   or   [N]o:");
		scanf("%c",&cho);
		getchar();
		if(cho=='Y'||cho=='y'){
			MaiAccount_UI_Mgt();	
		}
	}
	return 0;
}

char Account_UI_Status2Char(account_type_t status)
{
	if (status == 0)
		return 'N';
	else if (status == 1)
		return 'X';
	else if (status == 9)
		return 'A';
	else if (status == 2)
		return 'M';
}

void Account_UI_MgtEntry(void)
{
	int i;
	if (gl_CurUser.type != USR_ADMIN)
	{
		printf("you can't join in there!please input the [Enter]");
		getchar();
		return ;
	}

	int ii, id;
	char choice, usrName[20];

	account_list_t head;
	account_node_t *pos;
	Pagination_t paging;

	List_Init(head, account_node_t);
	paging.offset = 0;
	paging.pageSize = Account_PAGE_SIZE;
	
	paging.totalRecords = Account_Srv_FetchAll(head);
	Paging_Locate_FirstPage(head, paging);
	
	do{
        system("clear");
        printf("\n\t\t===================================================================================================");
        printf("\n\t\t*************************************User management***********************************************");
        printf("\n\t\t===================================================================================================");
        printf("\n\n\t\t    %-25s%-25s%-25s\n","User_ID","User_Name","User_type");
        Paging_ViewPage_ForEach(head,paging,account_node_t,pos,i){
            printf("\n\t\t  %-25d%-25s",pos->data.id,pos->data.username);
            if(pos->data.type==0)   printf("%-25s\n","Other_user");
            else if(pos->data.type==1)  printf("%-25s\n","Salesman");
            else if(pos->data.type==2)  printf("%-25s\n","Management");
            else printf("%-25s\n","Adminasrater");
        }
        printf("\n\t\t-----All member:%2d----------------------------------No.%2d All page:%2d------------------------\n",
            paging.totalRecords,Pageing_CurPage(paging),Pageing_TotalPages(paging));

        printf("\n\t\t=================================================================================================");
		printf("\n\n\t\t	   	[A]Add user                     [D]Delete user                     \n");
		printf("\t\t                                                          					    \n");
		printf("\t\t 			[F]Modify infomation       	[Q]Query         	   		            \n");
		printf("\t\t                                                                       		    \n");
		printf("\t\t 			[P]Previous page           	[N]Next page          	   		        \n");
		printf("\t\t                                                          	       	   		    \n");
		printf("\t\t 			[E]Exit                                                    		    \n");
		printf("\t\t                                                          					    \n");
		printf("\t\t***************************************************************************************************");
		printf("\n\t\t===============================================================================================\n");
		printf("\n\t\tInput you choice:");
		choice=getchar();
		while('\n'!=getchar());
		switch (choice)
		{
		case 'a':
		case 'A':system("clear");

			if (Account_UI_Add(head)) 
			{
				paging.totalRecords = Account_Srv_FetchAll(head);

			}
			else
			{
				printf("this user is already have\n");
			}
			break;
		case 'd':
		case 'D':
			system("clear");

			printf("Input the username:");
			setbuf(stdin, NULL);
			scanf("%s", usrName);
			getchar();
			if (Account_UI_Delete(head, usrName))
			{ //������������
				printf("delete accept\n");
				paging.totalRecords = Account_Srv_FetchAll(head);
				List_Paging(head, paging, account_node_t);
			}
			else
			{
				printf("delete error\n");
			}
			break;
		case 'q':
		case 'Q':
			system("clear");

			printf("Input the username:");
			setbuf(stdin, NULL);
			scanf("%s", usrName);
			getchar();
			if (Account_UI_Query(head, usrName))
			{ 
				paging.totalRecords = Account_Srv_FetchAll(head);
				List_Paging(head, paging, account_node_t);
			}
			else
			{
				printf("query error\n");
			}
			break;
		case 'm':
		case 'M':
			system("clear");

			printf("Input the username:");
			setbuf(stdin, NULL);
			scanf("%s", usrName);
			getchar();
			if (Account_UI_Modify(head, usrName))
			{
				printf("mod accept\n");
				paging.totalRecords = Account_Srv_FetchAll(head);
				List_Paging(head, paging, account_node_t);
			}
			break;
		case 'p':
		case 'P': system("clear");

			if (!Pageing_IsFirstPage(paging))
			{
				Paging_Locate_OffsetPage(head, paging, -1, account_node_t);
			}
			break;
		case 'n':
		case 'N': system("clear");

			if (!Pageing_IsLastPage(paging))
			{
				Paging_Locate_OffsetPage(head, paging, 1, account_node_t);
			}
			break;
		}
	} while (choice != 'e' && choice != 'E');
	List_Destroy(head, account_node_t);
}
int Account_UI_Add(account_list_t list)
{
	account_t data;
	int newRecCount = 0;
	char choice;

	do
	{
		printf("\n==================================================================\n");
		printf("**************************  Add New User **************************\n");
		printf("-------------------------------------------------------------------\n");
		printf("please input you want add newname :");
		setbuf(stdin, NULL);
		scanf("%s", data.username);

		getchar();
		printf("===================================================================\n");
		account_list_t temp = Account_Srv_FindByUsrName(list, data.username);
		if (temp != NULL)
		{
			printf("this user is already have\n");
			printf("[A]dd other, [R]eturn:");
			setbuf(stdin, NULL);
			scanf("%c", &choice);
			getchar();
		}
		else
		{
			printf("please input you want passsword :");
			setbuf(stdin, NULL);
			char password[35];


			for (int i = 0; i < len1; i++)
			{
			password[i] = getch();
			if (password[i] == '\n')
			{
				password[i] = '\0';
				break;
			}
			if ((int)password[i] == 127)
			{
				printf("\b \b");
				i = i - 2;
			}
			else
			{
				printf("*");
			}
			if (i < 0)
				password[0] = '\0';
		}


			unsigned char decrypt[16];

		//	getchar();
			printf("please input you want type :\n");
			printf("===================================================================\n");
			printf("[0]匿名用户  |  [1]售票员  |  [2]经理  |  [9]系统管理员:");

			setbuf(stdin, NULL);
			scanf("%d", &data.type);
			getchar();
			printf("Please enter your security questions.\n");
			scanf("%s",data.mipao);
			getchar();

			if (Account_Srv_Add(&data))
			{
				newRecCount += 1;
				Account_Srv_FetchAll(list);
				printf("The new user added successfully!\n");
			}
			else
				printf("The new user added failed!\n");
			//getchar();
			printf("-------------------------------------------------------------------\n");
			printf("[A]dd more, [R]eturn:");
			setbuf(stdin, NULL);
			scanf("%c", &choice);
			char ch;
			while ((ch = getchar()) != '\n' && ch != EOF);
		}
	} while ('a' == choice || 'A' == choice);
	return newRecCount;
}

//修改系统用户界面
int Account_UI_Modify(account_list_t list, char usrName[])
{
	account_list_t temp = Account_Srv_FindByUsrName(list, usrName);
	if (temp != NULL)
	{
		int choice = 10;
		do
		{
			char password[20];
			printf("prease input the new password:");
			setbuf(stdin, NULL);
			int x;

		//	scanf("%s", password);


			for (int i = 0; i < len1; i++)
			{
			password[i] = getch();
			if (password[i] == '\n')
			{
				password[i] = '\0';
				break;
			}
			if ((int)password[i] == 127)
			{
				printf("\b \b");
				i = i - 2;
			}
			else
			{
				printf("*");
			}
			if (i < 0)
				password[0] = '\0';
		}


			unsigned char decrypt[16];
			for (int i = 0; i < 16; i++)
			{
				if (decrypt[i] != temp->data.password[i])
					x = 0;
			}
			if (x)
			{
				printf("mod error,password the same,please choice next\n");
				printf("[0]exit  |   [1]input again\n");
				scanf("%d", &choice);
				setbuf(stdin, NULL);
			}
			else
			{
				for (int i = 0; i < 16; i++)
				{
					//printf("%02x", decrypt[i]);
					temp->data.password[i] = decrypt[i];
				}
				int aaa = Account_Srv_Modify(&(temp->data));
				if (aaa == 0)
				{
					return 0;
				}
				Account_Srv_FetchAll(list);

				return 1;
			}
		} while (choice != 0);
	}
	else
	{
		printf("The user does not exist!\n");
		return 0;
	}
}

//删除系统用户界面
int Account_UI_Delete(account_list_t list, char usrName[])
{
	account_list_t temp = Account_Srv_FindByUsrName(list, usrName);
	if (temp != NULL)
	{
		Account_Srv_DeleteByID(temp->data.id);
		Account_Srv_FetchAll(list);
		return 1;
	}
	return 0;
}

//查询用户界面
int Account_UI_Query(account_list_t list, char usrName[])
{
	account_list_t temp = Account_Srv_FindByUsrName(list, usrName);
	if (temp != NULL)
	{
		printf("user ID:%d\n", temp->data.id);
		printf("user password:\n");
		print(temp->data.password);
		putchar('\n');
		printf("user username:%s\n", temp->data.username);
		printf("user type:%c\n", Account_UI_Status2Char(temp->data.type));

		return 1;
	}
	return 0;
}
