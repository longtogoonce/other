#ifndef SCHEDULE_UI_H_
#define SCHEDULE_UI_H_

void Schedule_UI_MgtEntry(int play_id);    //xian shi  id hao wei play_id de ju mu de xiang guan lian de suo you yan chu ji hua 

int Schedule_UI_Add(int play_id);

int Schedule_UI_Modify(int id);

int Schedule_UI_Delete(int id);

int Schedule_UI_Qry(char *play_name);

void Schedule_UI_ListAll(void);

#endif
