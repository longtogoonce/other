#ifndef SALESANALYSIS_UI_H_
#define SALESANALYSIS_UI_H_
#include "../Service/SalesAnalysis.h"
#include "../Common/list.h"
#include "../Service/Account.h"
#include "../Service/Ticket.h"
#include "../Service/Play.h"
#include "../Service/Schedule.h"
#include "../Service/Sale.h"

//统计票房界面
void SalesAnalysis_UI_MgtEntry ();

#endif

