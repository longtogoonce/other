#ifndef MAIACCOUNT_UI_H_
#define MAIACCOUNT_UI_H_

#include "../Common/list.h"
#include "../Service/Account.h"

static const int MAIACCOUNT_PAGE_SIZE=6;

//维护个人资料管理入口界面
void MaiAccount_UI_MgtEntry ();
void MaiAccount_UI_Mgt ();
#endif /* MAIACCOUNT_UI_H_ */
